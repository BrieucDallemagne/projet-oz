#!/bin/bash


#Need to make it work for Linux
cd Pickle
rm  -r Word
mkdir Word